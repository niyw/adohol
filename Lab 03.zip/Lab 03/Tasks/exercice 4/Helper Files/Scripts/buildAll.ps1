#UI Projects: Restore and Build
dotnet build ./ModernUIAppSolution/ModernUIApp/ModernUIApp.csproj ; dotnet build ./ModernUIAppSolution/ModernUIApp.Tests/ModernUIApp.Tests.csproj
#API Projects: Restore and Build
dotnet build ./ModernUIAppSolution/ModernUIApp/ModernUIApp.csproj ; dotnet build ./ModernApiAppSolution/ModernApiApp.Entities/ModernApiApp.Entities.csproj ; dotnet build ./ModernApiAppSolution/ModernApiApp.DataAccess/ModernApiApp.DataAccess.csproj ;dotnet build ./ModernApiAppSolution/ModernApiApp.Tests/ModernApiApp.Tests.csproj;
