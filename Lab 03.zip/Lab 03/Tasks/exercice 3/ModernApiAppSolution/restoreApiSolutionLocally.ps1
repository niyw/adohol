Set-ExecutionPolicy Bypass
dotnet restore ./ModernApiApp/ModernApiApp.csproj ; dotnet restore ./ModernApiApp.Tests/ModernApiApp.Tests.csproj